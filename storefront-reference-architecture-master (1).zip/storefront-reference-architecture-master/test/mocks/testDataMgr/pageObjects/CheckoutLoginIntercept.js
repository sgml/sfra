'use strict';


export const BTN_CHECKOUT_AS_GUEST = '.checkout-as-guest';
