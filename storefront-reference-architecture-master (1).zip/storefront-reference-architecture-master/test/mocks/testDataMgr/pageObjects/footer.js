'use strict';

export const FOOTER_CONTAINER = '.footer-container';
