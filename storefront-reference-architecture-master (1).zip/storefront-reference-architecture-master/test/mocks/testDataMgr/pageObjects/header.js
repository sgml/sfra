'use strict';

export const NAV_BAR_TOGGLER = '.navbar-toggler';
