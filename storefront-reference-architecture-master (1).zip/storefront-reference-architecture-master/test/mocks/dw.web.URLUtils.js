'use strict';


module.exports = {
    http: function (id) {
        return id;
    },
    staticURL: function () {
        return 'some url';
    },
    url: function () {
        return 'someUrl';
    }
};
